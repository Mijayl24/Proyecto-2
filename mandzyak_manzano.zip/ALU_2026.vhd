----------------------------------------------------------------------------------
-- Company: 
-- Engineer: 
-- 
-- Create Date:    12:10:07 04/01/2026 
-- Design Name: 
-- Module Name:    ALU - Behavioral with support for vectorial MAC with internal accumulation
-- Additional Comments: by AOC2 Team Unizar 
--
----------------------------------------------------------------------------------
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
--use IEEE.std_logic_arith.all;
use IEEE.std_logic_unsigned.all;
-- Uncomment the following library declaration if using
-- arithmetic functions with Signed or Unsigned values
use IEEE.NUMERIC_STD.ALL;



entity ALU_Vector_MAC is
    Port ( DA : in  STD_LOGIC_VECTOR (31 downto 0); --input 1
           DB : in  STD_LOGIC_VECTOR (31 downto 0); --input 2
           valid_I_EX : in  STD_LOGIC;
           clk : in  STD_LOGIC;
		   reset : in  STD_LOGIC;
		   ready : out STD_LOGIC; --initially is always '1', but if ALU supports multicycle ops, it will be cero when the output is not ready
           ALUctrl : in  STD_LOGIC_VECTOR (2 downto 0); -- Ops: "000" add, "001" sub, "010" AND, "011" OR, "100" MAC with internal acc, "101" MAC without previous acc.
           Dout : out  STD_LOGIC_VECTOR (31 downto 0)); -- Output
end ALU_Vector_MAC;

architecture Behavioral of ALU_Vector_MAC is

component reg is
    generic (size: natural := 32);  -- por defecto son de 32 bits, pero se puede usar cualquier tama�o
	Port ( Din : in  STD_LOGIC_VECTOR (size -1 downto 0);
           clk : in  STD_LOGIC;
		   reset : in  STD_LOGIC;
           load : in  STD_LOGIC;
           Dout : out  STD_LOGIC_VECTOR (size -1 downto 0));
end component;

signal Dout_internal: STD_LOGIC_VECTOR (31 downto 0);
signal ACC_out : STD_LOGIC_VECTOR (31 downto 0) := X"00000000";
signal ACC_input, sum_total_ext: Signed (31 downto 0);
signal prod0, prod1, prod2, prod3 : Signed(15 downto 0);
signal prod0_out, prod1_out, prod2_out, prod3_out : STD_LOGIC_VECTOR(15 downto 0);
signal sum1, sum2 : Signed(16 downto 0);
signal sum_total : Signed(17 downto 0);
signal sum_total_out : STD_LOGIC_VECTOR(17 downto 0);
signal start, Acc_op, MAC_start, MAC1, MAC2, MAC3 ,load_acc : STD_LOGIC;		--A�ADIMOS SE�ALES PARA ESTADOS INTERMEDIO DE LA MAC
type state_type is (MacMul, MacAdd , MacAcc);							-- A�ADIMOS TIPOS DE ESTADO
signal state, next_state : state_type; 
begin
-- IMPORTANT
-- VHDL is strongly typed.
-- In VHDL, types do not just describe the size of a signal, they describe its meaning. 
-- A std_logic_vector means �a bundle of bits,� nothing more. 
-- A signed signal means �a two's complement number.� Because the language is strongly typed, VHDL won�t let you accidentally treat raw bits as a number or mix numeric and non-numeric types without being explicit.
-- In VHDL, you need to use the signed type for C2 (two�s-complement) arithmetic because arithmetic operators like +, -, and comparisons are only numerically defined for the signed and unsigned types in numeric_std, not for std_logic_vector. 
-- A std_logic_vector is just a collection of bits with no inherent numerical meaning, so the compiler has no way to know whether those bits represent a positive or negative number or how to interpret the sign bit.
-- By converting the operands to signed, you explicitly tell VHDL to interpret the MSB as the sign bit and to perform proper two�s-complement arithmetic. 
-- After the calculation, the result is typically converted back to std_logic_vector to store it in a register because registers and ports are often defined as std_logic_vector for generality and compatibility with other logic, interfaces, and synthesis tools. 
-- This separation keeps arithmetic correct and unambiguous while still allowing flexible storage and data movement.
-- NOTE: If you add additional registers you will have to adjust types
-- See the ACC_register for an example: 
-- 1) To use ACC_input as input, first it is transformed to std_logic_vector with: std_logic_vector(ACC_input)
-- 2) To use the output for signed arithmetic operations, first it is transformed to signed: else sum_total_ext + signed(ACC_out);

	prod0 <= signed(DA(7 downto 0))   * signed(DB(7 downto 0));
	prod1 <= signed(DA(15 downto 8))  * signed(DB(15 downto 8));
	prod2 <= signed(DA(23 downto 16)) * signed(DB(23 downto 16));
	prod3 <= signed(DA(31 downto 24)) * signed(DB(31 downto 24));
	sum1 <= signed(prod0_out(15) & prod0_out) + signed(prod1_out(15) & prod1_out); --A�ADIDO
	sum2 <= signed(prod2_out(15) & prod2_out) + signed(prod3_out(15) & prod3_out); --A�ADIDO
	sum_total <= (sum1(16) & sum1) + (sum2(16) & sum2); --A�ADIDO
	sum_total_ext(17 downto 0) <= signed(sum_total_out); --A�ADIDO
	sum_total_ext(31 downto 18) <= "00000000000000" when sum_total_out(17)='0' else "11111111111111";
	
	--It is important not to update the ACC register with invalid instructions
	Acc_op <= '1' when (ALUctrl(2 downto 1) = "10") else '0'; --Acc operations: "100" and "101" 
	start <= Acc_op and valid_I_EX; 	--A�DIDO: CAMBIAR load_acc POR start, YA QUE AHORA TENEMOS 3 CICLOS
	MAC_start <=   '1' when (ALUctrl(0) = '1') else '0'; -- If ALUCtrl = "101" the accumulation register is restarted
	
	ACC_input	 <= 	sum_total_ext when (MAC_start = '1')
						else sum_total_ext + signed(ACC_out);	
	--reset is currentlly unused in the ALU, but it will be needed if it becomes multicycle
	ACC_register: reg 	generic map (size => 32)
						port map (	Din => std_logic_vector(ACC_input), clk => clk, reset => '0', load => load_acc, Dout => ACC_out);
	
	----------------------------------------------------------A�ADIDO NUEVO-------------------------------------------------------------
	prod0_register: reg 	generic map (size => 16)
						port map (	Din => std_logic_vector(prod0), clk => clk, reset => reset, load => MAC1, Dout => prod0_out);
	
	prod1_register: reg 	generic map (size => 16)
						port map (	Din => std_logic_vector(prod1), clk => clk, reset => reset, load => MAC1, Dout => prod1_out);
	
	prod2_register: reg 	generic map (size => 16)
						port map (	Din => std_logic_vector(prod2), clk => clk, reset => reset, load => MAC1, Dout => prod2_out);
	
	prod3_register: reg 	generic map (size => 16)
						port map (	Din => std_logic_vector(prod3), clk => clk, reset => reset, load => MAC1, Dout => prod3_out);

	sum_total_register: reg 	generic map (size => 18)
						port map (	Din => std_logic_vector(sum_total), clk => clk, reset => reset, load => MAC2, Dout => sum_total_out);
						
	
	State_reg: process (clk)
	begin
		if (clk'event and clk = '1') then
			if (reset = '1') then
			state <= MacMul;
			else
			state <= next_state;
			end if;        
		end if;
	end process;
	
	-- UC mealy, this process includes the logic that generates the next state and the outputs
	-- The sensitivity list is wrong. What should it be there? Does it make any sense to include clk in this is combinatorial logic?



	UC_outputs : process (state, start, ALUctrl)
	begin
	    -- Valores por defecto: todo a '0'
		MAC1 <= '0';
	    MAC2 <= '0';
	    MAC3 <= '0';
		next_state <= MacMul;
		
	    CASE state IS

		-- Espera hasta que llegue una MAC v�lida
		WHEN MacMul =>
		    IF (start = '1' AND (ALUctrl(2 downto 1) = "10")) THEN
		        next_state     <= MacAdd;
		        MAC1     <= '1';   -- ciclo 1: cargar productos
		    END IF;

		-- Ciclo 2: las sumas combinacionales ya est�n listas,
		-- cargamos sum_total_register
		WHEN MacAdd =>
		    next_state  <= MacAcc;
		    MAC2  <= '1';          -- ciclo 2: cargar sum_total

		-- Ciclo 3: sum_total_out ya estable, cargamos ACC y se�alamos done
		WHEN MacAcc =>
		    next_state        <= MacMul;
		    MAC3 <= '1';    -- ciclo 3: cargar ACC

		WHEN OTHERS =>
		    next_state <= MacMul;

	    END CASE;
	end process;
					
	load_acc <= '1'when ((MAC3 ='1') and (reset = '0')) else '0';
	
	Dout_internal <= 	DA + DB when (ALUctrl="000") 
				else DA - DB when (ALUctrl="001") 
				else DA AND DB when (ALUctrl="010")
				else DA OR DB when (ALUctrl="011")
				else std_logic_vector(ACC_input) when (ALUctrl(2 downto 1) = "10")
				else "00000000000000000000000000000000";
	Dout <= Dout_internal;
	-- to be updated:
	ready <= '0' WHEN ((state = MacMul and start = '1') or state = MacAdd) else '1';		--A�ADIDO
end Behavioral;
